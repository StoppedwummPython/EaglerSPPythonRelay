package org.java_websocket.framing;

// $FF: synthetic class
interface package-info {
}
