package org.java_websocket.client;

// $FF: synthetic class
interface package-info {
}
