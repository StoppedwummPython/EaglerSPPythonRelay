package org.java_websocket.drafts;

// $FF: synthetic class
interface package-info {
}
