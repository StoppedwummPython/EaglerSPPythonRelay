package org.java_websocket.extensions;

// $FF: synthetic class
interface package-info {
}
