package org.java_websocket.handshake;

// $FF: synthetic class
interface package-info {
}
