package org.java_websocket.interfaces;

import javax.net.ssl.SSLEngine;

public interface ISSLChannel {
   SSLEngine getSSLEngine();
}
