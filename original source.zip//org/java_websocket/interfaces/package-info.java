package org.java_websocket.interfaces;

// $FF: synthetic class
interface package-info {
}
