package org.java_websocket.exceptions;

// $FF: synthetic class
interface package-info {
}
