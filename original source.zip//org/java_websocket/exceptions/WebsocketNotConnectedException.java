package org.java_websocket.exceptions;

public class WebsocketNotConnectedException extends RuntimeException {
   private static final long serialVersionUID = -785314021592982715L;
}
