package org.java_websocket.protocols;

// $FF: synthetic class
interface package-info {
}
