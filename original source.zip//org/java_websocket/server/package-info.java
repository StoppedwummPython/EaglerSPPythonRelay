package org.java_websocket.server;

// $FF: synthetic class
interface package-info {
}
