package org.java_websocket.enums;

public enum Role {
   CLIENT,
   SERVER;

   // $FF: synthetic method
   private static Role[] $values() {
      return new Role[]{CLIENT, SERVER};
   }
}
