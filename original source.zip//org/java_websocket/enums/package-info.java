package org.java_websocket.enums;

// $FF: synthetic class
interface package-info {
}
