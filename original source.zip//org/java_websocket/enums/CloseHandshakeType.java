package org.java_websocket.enums;

public enum CloseHandshakeType {
   NONE,
   ONEWAY,
   TWOWAY;

   // $FF: synthetic method
   private static CloseHandshakeType[] $values() {
      return new CloseHandshakeType[]{NONE, ONEWAY, TWOWAY};
   }
}
