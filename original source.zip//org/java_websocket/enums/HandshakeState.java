package org.java_websocket.enums;

public enum HandshakeState {
   MATCHED,
   NOT_MATCHED;

   // $FF: synthetic method
   private static HandshakeState[] $values() {
      return new HandshakeState[]{MATCHED, NOT_MATCHED};
   }
}
