package org.java_websocket.util;

// $FF: synthetic class
interface package-info {
}
