package org.slf4j.spi;

public interface CallerBoundaryAware {
   void setCallerBoundary(String var1);
}
