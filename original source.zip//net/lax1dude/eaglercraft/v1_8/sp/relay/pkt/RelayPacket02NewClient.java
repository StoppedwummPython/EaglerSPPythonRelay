package net.lax1dude.eaglercraft.v1_8.sp.relay.pkt;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class RelayPacket02NewClient extends RelayPacket {
   public String clientId;

   public RelayPacket02NewClient(String clientId) {
      this.clientId = clientId;
   }

   public RelayPacket02NewClient() {
   }

   public void write(DataOutputStream output) throws IOException {
      writeASCII8(output, this.clientId);
   }

   public void read(DataInputStream input) throws IOException {
      this.clientId = readASCII8(input);
   }

   public int packetLength() {
      return 1 + this.clientId.length();
   }
}
