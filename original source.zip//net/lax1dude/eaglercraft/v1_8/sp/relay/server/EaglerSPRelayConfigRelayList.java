package net.lax1dude.eaglercraft.v1_8.sp.relay.server;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collection;
import net.lax1dude.eaglercraft.v1_8.sp.relay.pkt.RelayPacket01ICEServers;

public class EaglerSPRelayConfigRelayList {
   public static final Collection<RelayPacket01ICEServers.RelayServer> relayServers = new ArrayList();

   public static void loadRelays(File list) throws IOException {
      ArrayList<RelayPacket01ICEServers.RelayServer> loading = new ArrayList();
      if (!list.isFile()) {
         EaglerSPRelay.logger.info("Creating new {}...", list.getName());
         InputStream is = EaglerSPRelayConfigRelayList.class.getResourceAsStream("/relays.txt");

         try {
            FileOutputStream os = new FileOutputStream(list);

            try {
               byte[] buffer = new byte[4096];

               int i;
               while((i = is.read(buffer)) != -1) {
                  os.write(buffer, 0, i);
               }
            } catch (Throwable var15) {
               try {
                  os.close();
               } catch (Throwable var13) {
                  var15.addSuppressed(var13);
               }

               throw var15;
            }

            os.close();
         } catch (Throwable var16) {
            if (is != null) {
               try {
                  is.close();
               } catch (Throwable var12) {
                  var16.addSuppressed(var12);
               }
            }

            throw var16;
         }

         if (is != null) {
            is.close();
         }
      }

      EaglerSPRelay.logger.info("Loading STUN/TURN relays from: {}", list.getName());
      RelayPacket01ICEServers.RelayType addType = null;
      String addAddress = null;
      String addUsername = null;
      String addPassword = null;
      BufferedReader reader = new BufferedReader(new FileReader(list));

      String line;
      try {
         while((line = reader.readLine()) != null) {
            line = line.trim();
            if (line.length() != 0 && !line.startsWith("#")) {
               boolean isNOPASSHead = line.equals("[NO_PASSWD]") || line.equals("[STUN]");
               boolean isPASSHead = line.equals("[PASSWD]") || line.equals("[TURN]");
               if (isNOPASSHead || isPASSHead) {
                  if (addType != null) {
                     add(list.getName(), loading, addType, addAddress, addUsername, addPassword);
                  }

                  addAddress = null;
                  addUsername = null;
                  addPassword = null;
                  addType = null;
               }

               if (isNOPASSHead) {
                  addType = RelayPacket01ICEServers.RelayType.NO_PASSWD;
               } else if (isPASSHead) {
                  addType = RelayPacket01ICEServers.RelayType.PASSWD;
               } else {
                  int spidx;
                  if (line.startsWith("url")) {
                     spidx = line.indexOf(61) + 1;
                     if (spidx < 3) {
                        EaglerSPRelay.logger.error("Error: Invalid line in {}: ", line);
                     } else {
                        line = line.substring(spidx).trim();
                        if (line.length() < 1) {
                           EaglerSPRelay.logger.error("Error: Invalid line in {}: ", line);
                        } else {
                           addAddress = line;
                        }
                     }
                  } else if (line.startsWith("username")) {
                     spidx = line.indexOf(61) + 1;
                     if (spidx < 8) {
                        EaglerSPRelay.logger.error("Error: Invalid line in {}: ", line);
                     } else {
                        line = line.substring(spidx).trim();
                        if (line.length() < 1) {
                           EaglerSPRelay.logger.error("Error: Invalid line in {}: ", line);
                        } else {
                           addUsername = line;
                        }
                     }
                  } else if (line.startsWith("password")) {
                     spidx = line.indexOf(61) + 1;
                     if (spidx < 8) {
                        EaglerSPRelay.logger.error("Error: Invalid line in {}: ", line);
                     } else {
                        line = line.substring(spidx).trim();
                        if (line.length() < 1) {
                           EaglerSPRelay.logger.error("Error: Invalid line in {}: ", line);
                        } else {
                           addPassword = line;
                        }
                     }
                  } else {
                     EaglerSPRelay.logger.error("Error: Invalid line in {}: ", line);
                  }
               }
            }
         }
      } catch (Throwable var14) {
         try {
            reader.close();
         } catch (Throwable var11) {
            var14.addSuppressed(var11);
         }

         throw var14;
      }

      reader.close();
      if (addType != null) {
         add(list.getName(), loading, addType, addAddress, addUsername, addPassword);
      }

      if (loading.size() == 0) {
         throw new IOException(list.getName() + ": no servers loaded");
      } else {
         relayServers.clear();
         relayServers.addAll(loading);
      }
   }

   private static void add(String filename, Collection<RelayPacket01ICEServers.RelayServer> loading, RelayPacket01ICEServers.RelayType type, String url, String user, String pass) {
      if (url == null) {
         EaglerSPRelay.logger.error("Error: Invalid relay in {}, missing 'url'", filename);
      } else {
         loading.add(new RelayPacket01ICEServers.RelayServer(url, type, user, pass));
      }

   }
}
