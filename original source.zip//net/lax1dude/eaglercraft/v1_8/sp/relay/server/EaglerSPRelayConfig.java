package net.lax1dude.eaglercraft.v1_8.sp.relay.server;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class EaglerSPRelayConfig {
   private String address = "0.0.0.0";
   private int port = 6699;
   private int codeLength = 5;
   private String codeChars = "abcdefghijklmnopqrstuvwxyz0123456789";
   private boolean codeMixCase = false;
   private int connectionsPerIP = 128;
   private int worldsPerIP = 32;
   private boolean openRateLimitEnable = true;
   private int openRateLimitPeriod = 192;
   private int openRateLimitLimit = 32;
   private int openRateLimitLockoutLimit = 48;
   private int openRateLimitLockoutDuration = 600;
   private boolean pingRateLimitEnable = true;
   private int pingRateLimitPeriod = 256;
   private int pingRateLimitLimit = 128;
   private int pingRateLimitLockoutLimit = 192;
   private int pingRateLimitLockoutDuration = 300;
   private String originWhitelist = "";
   private String[] originWhitelistArray = new String[0];
   private boolean enableRealIpHeader = false;
   private String realIpHeaderName = "X-Real-IP";
   private boolean enableShowLocals = true;
   private String serverComment = "Eags. Shared World Relay";

   public void load(File conf) {
      if (!conf.isFile()) {
         EaglerSPRelay.logger.info("Creating config file: {}", conf.getAbsoluteFile());
         this.save(conf);
      } else {
         EaglerSPRelay.logger.info("Loading config file: {}", conf.getAbsoluteFile());
         boolean gotPort = false;
         boolean gotCodeLength = false;
         boolean gotCodeChars = false;
         boolean gotCodeMixCase = false;
         boolean gotConnectionsPerIP = false;
         boolean gotWorldsPerIP = false;
         boolean gotOpenRateLimitEnable = false;
         boolean gotOpenRateLimitPeriod = false;
         boolean gotOpenRateLimitLimit = false;
         boolean gotOpenRateLimitLockoutLimit = false;
         boolean gotOpenRateLimitLockoutDuration = false;
         boolean gotPingRateLimitEnable = false;
         boolean gotPingRateLimitPeriod = false;
         boolean gotPingRateLimitLimit = false;
         boolean gotPingRateLimitLockoutLimit = false;
         boolean gotPingRateLimitLockoutDuration = false;
         boolean gotOriginWhitelist = false;
         boolean gotEnableRealIpHeader = false;
         boolean gotRealIpHeaderName = false;
         boolean gotAddress = false;
         boolean gotComment = false;
         boolean gotShowLocals = false;
         Object t2 = null;

         try {
            BufferedReader reader = new BufferedReader(new FileReader(conf));

            String s;
            try {
               while((s = reader.readLine()) != null) {
                  String[] ss = s.trim().split(":", 2);
                  if (ss.length == 2) {
                     ss[0] = ss[0].trim();
                     ss[1] = ss[1].trim();
                     if (ss[0].equalsIgnoreCase("port")) {
                        try {
                           this.port = Integer.parseInt(ss[1]);
                           gotPort = true;
                        } catch (Throwable var30) {
                           t2 = var30;
                           break;
                        }
                     } else if (ss[0].equalsIgnoreCase("address")) {
                        this.address = ss[1];
                        gotAddress = true;
                     } else if (ss[0].equalsIgnoreCase("code-length")) {
                        try {
                           this.codeLength = Integer.parseInt(ss[1]);
                           gotCodeLength = true;
                        } catch (Throwable var46) {
                           EaglerSPRelay.logger.warn("Invalid code-length {} in conf {}", ss[1], conf.getAbsoluteFile());
                           EaglerSPRelay.logger.warn(var46);
                           t2 = var46;
                           break;
                        }
                     } else if (ss[0].equalsIgnoreCase("code-chars")) {
                        if (ss[1].length() < 2) {
                           t2 = new IllegalArgumentException("not enough chars");
                           EaglerSPRelay.logger.warn("Invalid code-chars {} in conf {}", ss[1], conf.getAbsoluteFile());
                           EaglerSPRelay.logger.warn((Throwable)t2);
                        } else {
                           this.codeChars = ss[1];
                           gotCodeChars = true;
                        }
                     } else if (ss[0].equalsIgnoreCase("code-mix-case")) {
                        try {
                           this.codeMixCase = getBooleanValue(ss[1]);
                           gotCodeMixCase = true;
                        } catch (Throwable var45) {
                           EaglerSPRelay.logger.warn("Invalid code-mix-case {} in conf {}", ss[1], conf.getAbsoluteFile());
                           EaglerSPRelay.logger.warn(var45);
                           t2 = var45;
                           break;
                        }
                     } else if (ss[0].equalsIgnoreCase("worlds-per-ip")) {
                        try {
                           this.worldsPerIP = Integer.parseInt(ss[1]);
                           gotWorldsPerIP = true;
                        } catch (Throwable var44) {
                           EaglerSPRelay.logger.warn("Invalid worlds-per-ip {} in conf {}", ss[1], conf.getAbsoluteFile());
                           EaglerSPRelay.logger.warn(var44);
                           t2 = var44;
                           break;
                        }
                     } else if (ss[0].equalsIgnoreCase("world-ratelimit-enable")) {
                        try {
                           this.openRateLimitEnable = getBooleanValue(ss[1]);
                           gotOpenRateLimitEnable = true;
                        } catch (Throwable var43) {
                           EaglerSPRelay.logger.warn("Invalid world-ratelimit-enable {} in conf {}", ss[1], conf.getAbsoluteFile());
                           EaglerSPRelay.logger.warn(var43);
                           t2 = var43;
                           break;
                        }
                     } else if (ss[0].equalsIgnoreCase("world-ratelimit-period")) {
                        try {
                           this.openRateLimitPeriod = Integer.parseInt(ss[1]);
                           gotOpenRateLimitPeriod = true;
                        } catch (Throwable var42) {
                           EaglerSPRelay.logger.warn("Invalid world-ratelimit-period {} in conf {}", ss[1], conf.getAbsoluteFile());
                           EaglerSPRelay.logger.warn(var42);
                           t2 = var42;
                           break;
                        }
                     } else if (ss[0].equalsIgnoreCase("world-ratelimit-limit")) {
                        try {
                           this.openRateLimitLimit = Integer.parseInt(ss[1]);
                           gotOpenRateLimitLimit = true;
                        } catch (Throwable var41) {
                           EaglerSPRelay.logger.warn("Invalid world-ratelimit-limit {} in conf {}", ss[1], conf.getAbsoluteFile());
                           EaglerSPRelay.logger.warn(var41);
                           t2 = var41;
                           break;
                        }
                     } else if (ss[0].equalsIgnoreCase("world-ratelimit-lockout-limit")) {
                        try {
                           this.openRateLimitLockoutLimit = Integer.parseInt(ss[1]);
                           gotOpenRateLimitLockoutLimit = true;
                        } catch (Throwable var40) {
                           EaglerSPRelay.logger.warn("Invalid world-ratelimit-lockout-limit {} in conf {}", ss[1], conf.getAbsoluteFile());
                           EaglerSPRelay.logger.warn(var40);
                           t2 = var40;
                           break;
                        }
                     } else if (ss[0].equalsIgnoreCase("world-ratelimit-lockout-duration")) {
                        try {
                           this.openRateLimitLockoutDuration = Integer.parseInt(ss[1]);
                           gotOpenRateLimitLockoutDuration = true;
                        } catch (Throwable var39) {
                           EaglerSPRelay.logger.warn("Invalid world-ratelimit-lockout-duration {} in conf {}", ss[1], conf.getAbsoluteFile());
                           EaglerSPRelay.logger.warn(var39);
                           t2 = var39;
                           break;
                        }
                     } else if (ss[0].equalsIgnoreCase("connections-per-ip")) {
                        try {
                           this.connectionsPerIP = Integer.parseInt(ss[1]);
                           gotConnectionsPerIP = true;
                        } catch (Throwable var38) {
                           EaglerSPRelay.logger.warn("Invalid connections-per-ip {} in conf {}", ss[1], conf.getAbsoluteFile());
                           EaglerSPRelay.logger.warn(var38);
                           t2 = var38;
                           break;
                        }
                     } else if (ss[0].equalsIgnoreCase("ping-ratelimit-enable")) {
                        try {
                           this.pingRateLimitEnable = getBooleanValue(ss[1]);
                           gotPingRateLimitEnable = true;
                        } catch (Throwable var37) {
                           EaglerSPRelay.logger.warn("Invalid ping-ratelimit-enable {} in conf {}", ss[1], conf.getAbsoluteFile());
                           EaglerSPRelay.logger.warn(var37);
                           t2 = var37;
                           break;
                        }
                     } else if (ss[0].equalsIgnoreCase("ping-ratelimit-period")) {
                        try {
                           this.pingRateLimitPeriod = Integer.parseInt(ss[1]);
                           gotPingRateLimitPeriod = true;
                        } catch (Throwable var36) {
                           EaglerSPRelay.logger.warn("Invalid ping-ratelimit-period {} in conf {}", ss[1], conf.getAbsoluteFile());
                           EaglerSPRelay.logger.warn(var36);
                           t2 = var36;
                           break;
                        }
                     } else if (ss[0].equalsIgnoreCase("ping-ratelimit-limit")) {
                        try {
                           this.pingRateLimitLimit = Integer.parseInt(ss[1]);
                           gotPingRateLimitLimit = true;
                        } catch (Throwable var35) {
                           EaglerSPRelay.logger.warn("Invalid ping-ratelimit-limit {} in conf {}", ss[1], conf.getAbsoluteFile());
                           EaglerSPRelay.logger.warn(var35);
                           t2 = var35;
                           break;
                        }
                     } else if (ss[0].equalsIgnoreCase("ping-ratelimit-lockout-limit")) {
                        try {
                           this.pingRateLimitLockoutLimit = Integer.parseInt(ss[1]);
                           gotPingRateLimitLockoutLimit = true;
                        } catch (Throwable var34) {
                           EaglerSPRelay.logger.warn("Invalid ping-ratelimit-lockout-limit {} in conf {}", ss[1], conf.getAbsoluteFile());
                           EaglerSPRelay.logger.warn(var34);
                           t2 = var34;
                           break;
                        }
                     } else if (ss[0].equalsIgnoreCase("ping-ratelimit-lockout-duration")) {
                        try {
                           this.pingRateLimitLockoutDuration = Integer.parseInt(ss[1]);
                           gotPingRateLimitLockoutDuration = true;
                        } catch (Throwable var33) {
                           EaglerSPRelay.logger.warn("Invalid ping-ratelimit-lockout-duration {} in conf {}", ss[1], conf.getAbsoluteFile());
                           EaglerSPRelay.logger.warn(var33);
                           t2 = var33;
                           break;
                        }
                     } else if (ss[0].equalsIgnoreCase("origin-whitelist")) {
                        this.originWhitelist = ss[1];
                        gotOriginWhitelist = true;
                     } else if (ss[0].equalsIgnoreCase("enable-real-ip-header")) {
                        try {
                           this.enableRealIpHeader = getBooleanValue(ss[1]);
                           gotEnableRealIpHeader = true;
                        } catch (Throwable var32) {
                           EaglerSPRelay.logger.warn("Invalid enable-real-ip-header {} in conf {}", ss[1], conf.getAbsoluteFile());
                           EaglerSPRelay.logger.warn(var32);
                           t2 = var32;
                           break;
                        }
                     } else if (ss[0].equalsIgnoreCase("real-ip-header-name")) {
                        this.realIpHeaderName = ss[1];
                        gotRealIpHeaderName = true;
                     } else if (ss[0].equalsIgnoreCase("show-local-worlds")) {
                        try {
                           this.enableShowLocals = getBooleanValue(ss[1]);
                           gotShowLocals = true;
                        } catch (Throwable var31) {
                           EaglerSPRelay.logger.warn("Invalid show-local-worlds {} in conf {}", ss[1], conf.getAbsoluteFile());
                           EaglerSPRelay.logger.warn(var31);
                           t2 = var31;
                           break;
                        }
                     } else if (ss[0].equalsIgnoreCase("server-comment")) {
                        this.serverComment = ss[1];
                        gotComment = true;
                     }
                  }
               }
            } catch (Throwable var47) {
               try {
                  reader.close();
               } catch (Throwable var29) {
                  var47.addSuppressed(var29);
               }

               throw var47;
            }

            reader.close();
         } catch (IOException var48) {
            EaglerSPRelay.logger.error("Failed to load config file: {}", conf.getAbsoluteFile());
            EaglerSPRelay.logger.error((Throwable)var48);
         } catch (Throwable var49) {
            EaglerSPRelay.logger.warn("Invalid config file: {}", conf.getAbsoluteFile());
            EaglerSPRelay.logger.warn(var49);
            t2 = var49;
         }

         if (t2 != null || !gotPort || !gotCodeLength || !gotCodeChars || !gotCodeMixCase || !gotWorldsPerIP || !gotOpenRateLimitEnable || !gotOpenRateLimitPeriod || !gotOpenRateLimitLimit || !gotOpenRateLimitLockoutLimit || !gotOpenRateLimitLockoutDuration || !gotConnectionsPerIP || !gotPingRateLimitEnable || !gotPingRateLimitPeriod || !gotPingRateLimitLimit || !gotPingRateLimitLockoutLimit || !gotPingRateLimitLockoutDuration || !gotOriginWhitelist || !gotEnableRealIpHeader || !gotAddress || !gotComment || !gotShowLocals || !gotRealIpHeaderName) {
            EaglerSPRelay.logger.warn("Updating config file: {}", conf.getAbsoluteFile());
            this.save(conf);
         }

         String[] splitted = this.originWhitelist.split(";");
         List<String> splittedList = new ArrayList();

         int i;
         for(i = 0; i < splitted.length; ++i) {
            splitted[i] = splitted[i].trim().toLowerCase();
            if (splitted[i].length() > 0) {
               splittedList.add(splitted[i]);
            }
         }

         this.originWhitelistArray = new String[splittedList.size()];

         for(i = 0; i < this.originWhitelistArray.length; ++i) {
            this.originWhitelistArray[i] = (String)splittedList.get(i);
         }
      }

   }

   public void save(File conf) {
      try {
         PrintWriter w = new PrintWriter(new FileOutputStream(conf));

         try {
            w.println("[EaglerSPRelay]");
            w.println("address: " + this.address);
            w.println("port: " + this.port);
            w.println("code-length: " + this.codeLength);
            w.println("code-chars: " + this.codeChars);
            w.println("code-mix-case: " + this.codeMixCase);
            w.println("connections-per-ip: " + this.connectionsPerIP);
            w.println("ping-ratelimit-enable: " + this.pingRateLimitEnable);
            w.println("ping-ratelimit-period: " + this.pingRateLimitPeriod);
            w.println("ping-ratelimit-limit: " + this.pingRateLimitLimit);
            w.println("ping-ratelimit-lockout-limit: " + this.pingRateLimitLockoutLimit);
            w.println("ping-ratelimit-lockout-duration: " + this.pingRateLimitLockoutDuration);
            w.println("worlds-per-ip: " + this.worldsPerIP);
            w.println("world-ratelimit-enable: " + this.openRateLimitEnable);
            w.println("world-ratelimit-period: " + this.openRateLimitPeriod);
            w.println("world-ratelimit-limit: " + this.openRateLimitLimit);
            w.println("world-ratelimit-lockout-limit: " + this.openRateLimitLockoutLimit);
            w.println("world-ratelimit-lockout-duration: " + this.openRateLimitLockoutDuration);
            w.println("origin-whitelist: " + this.originWhitelist);
            w.println("real-ip-header-name: " + this.realIpHeaderName);
            w.println("enable-real-ip-header: " + this.enableRealIpHeader);
            w.println("show-local-worlds: " + this.isEnableShowLocals());
            w.print("server-comment: " + this.serverComment);
         } catch (Throwable var6) {
            try {
               w.close();
            } catch (Throwable var5) {
               var6.addSuppressed(var5);
            }

            throw var6;
         }

         w.close();
      } catch (IOException var7) {
         EaglerSPRelay.logger.error("Failed to write config file: {}", conf.getAbsoluteFile());
         EaglerSPRelay.logger.error((Throwable)var7);
      }

   }

   private static boolean getBooleanValue(String str) {
      if (!str.equalsIgnoreCase("true") && !str.equals("1")) {
         if (!str.equalsIgnoreCase("false") && !str.equals("0")) {
            throw new IllegalArgumentException("Not a boolean: " + str);
         } else {
            return false;
         }
      } else {
         return true;
      }
   }

   public String getAddress() {
      return this.address;
   }

   public int getPort() {
      return this.port;
   }

   public int getCodeLength() {
      return this.codeLength;
   }

   public String getCodeChars() {
      return this.codeChars;
   }

   public boolean isCodeMixCase() {
      return this.codeMixCase;
   }

   public int getConnectionsPerIP() {
      return this.connectionsPerIP;
   }

   public boolean isPingRateLimitEnable() {
      return this.pingRateLimitEnable;
   }

   public int getPingRateLimitPeriod() {
      return this.pingRateLimitPeriod;
   }

   public int getPingRateLimitLimit() {
      return this.pingRateLimitLimit;
   }

   public int getPingRateLimitLockoutLimit() {
      return this.pingRateLimitLockoutLimit;
   }

   public int getPingRateLimitLockoutDuration() {
      return this.pingRateLimitLockoutDuration;
   }

   public int getWorldsPerIP() {
      return this.worldsPerIP;
   }

   public boolean isWorldRateLimitEnable() {
      return this.openRateLimitEnable;
   }

   public int getWorldRateLimitPeriod() {
      return this.openRateLimitPeriod;
   }

   public int getWorldRateLimitLimit() {
      return this.openRateLimitLimit;
   }

   public int getWorldRateLimitLockoutLimit() {
      return this.openRateLimitLockoutLimit;
   }

   public int getWorldRateLimitLockoutDuration() {
      return this.openRateLimitLockoutDuration;
   }

   public String getOriginWhitelist() {
      return this.originWhitelist;
   }

   public String[] getOriginWhitelistArray() {
      return this.originWhitelistArray;
   }

   public boolean getIsWhitelisted(String domain) {
      if (this.originWhitelistArray.length == 0) {
         return true;
      } else {
         if (domain == null) {
            domain = "null";
         } else {
            domain = domain.toLowerCase();
            if (domain.equals("null")) {
               domain = "offline";
            } else if (domain.startsWith("http://")) {
               domain = domain.substring(7);
            } else if (domain.startsWith("https://")) {
               domain = domain.substring(8);
            }
         }

         for(int i = 0; i < this.originWhitelistArray.length; ++i) {
            String etr = this.originWhitelistArray[i].toLowerCase();
            if (etr.startsWith("*")) {
               if (domain.endsWith(etr.substring(1))) {
                  return true;
               }
            } else if (domain.equals(etr)) {
               return true;
            }
         }

         return false;
      }
   }

   public String getRealIPHeaderName() {
      return this.realIpHeaderName;
   }

   public boolean isEnableRealIpHeader() {
      return this.enableRealIpHeader;
   }

   public String getComment() {
      return this.serverComment;
   }

   public String generateCode() {
      Random r = new Random();
      char[] ret = new char[this.codeLength];

      for(int i = 0; i < this.codeLength; ++i) {
         ret[i] = this.codeChars.charAt(r.nextInt(this.codeChars.length()));
         if (this.codeMixCase) {
            if (r.nextBoolean()) {
               ret[i] = Character.toLowerCase(ret[i]);
            } else {
               ret[i] = Character.toUpperCase(ret[i]);
            }
         }
      }

      return new String(ret);
   }

   public boolean isEnableShowLocals() {
      return this.enableShowLocals;
   }
}
