package net.lax1dude.eaglercraft.v1_8.sp.relay.pkt;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class RelayPacket07LocalWorlds extends RelayPacket {
   public List<RelayPacket07LocalWorlds.LocalWorld> worldsList;

   public RelayPacket07LocalWorlds() {
   }

   public RelayPacket07LocalWorlds(List<RelayPacket07LocalWorlds.LocalWorld> worldsList) {
      this.worldsList = worldsList;
   }

   public void write(DataOutputStream output) throws IOException {
      if (this.worldsList == null) {
         output.write(0);
      } else {
         int i = this.worldsList.size();
         if (i > 255) {
            i = 255;
         }

         output.write(i);

         for(int j = 0; j < i; ++j) {
            RelayPacket07LocalWorlds.LocalWorld w = (RelayPacket07LocalWorlds.LocalWorld)this.worldsList.get(j);
            writeASCII8(output, w.worldName);
            writeASCII8(output, w.worldCode);
         }
      }

   }

   public void read(DataInputStream input) throws IOException {
      int l = input.read();
      if (this.worldsList == null) {
         this.worldsList = new ArrayList(l);
      } else {
         this.worldsList.clear();
      }

      for(int i = 0; i < l; ++i) {
         this.worldsList.add(new RelayPacket07LocalWorlds.LocalWorld(readASCII8(input), readASCII8(input)));
      }

   }

   public int packetLength() {
      int accum = 1;
      if (this.worldsList != null) {
         int i = 0;

         for(int l = this.worldsList.size(); i < l; ++i) {
            RelayPacket07LocalWorlds.LocalWorld j = (RelayPacket07LocalWorlds.LocalWorld)this.worldsList.get(i);
            accum += 2 + j.worldName.length() + j.worldCode.length();
         }
      }

      return accum;
   }

   public static class LocalWorld {
      public final String worldName;
      public final String worldCode;

      public LocalWorld(String worldName, String worldCode) {
         this.worldName = worldName;
         this.worldCode = worldCode;
      }
   }
}
