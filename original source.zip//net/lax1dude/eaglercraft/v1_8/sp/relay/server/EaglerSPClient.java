package net.lax1dude.eaglercraft.v1_8.sp.relay.server;

import java.io.IOException;
import java.util.Random;
import net.lax1dude.eaglercraft.v1_8.sp.relay.pkt.RelayPacket;
import net.lax1dude.eaglercraft.v1_8.sp.relay.pkt.RelayPacket03ICECandidate;
import net.lax1dude.eaglercraft.v1_8.sp.relay.pkt.RelayPacket04Description;
import net.lax1dude.eaglercraft.v1_8.sp.relay.pkt.RelayPacket05ClientSuccess;
import net.lax1dude.eaglercraft.v1_8.sp.relay.pkt.RelayPacket06ClientFailure;
import net.lax1dude.eaglercraft.v1_8.sp.relay.pkt.RelayPacketFEDisconnectClient;
import org.java_websocket.WebSocket;

public class EaglerSPClient {
   public final WebSocket socket;
   public final EaglerSPServer server;
   public final String id;
   public final long createdOn;
   public boolean serverNotifiedOfClose = false;
   public LoginState state;
   public final String address;
   public static final int clientCodeLength = 16;
   private static final String clientCodeChars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";

   EaglerSPClient(WebSocket sock, EaglerSPServer srv, String id, String addr) {
      this.state = LoginState.INIT;
      this.socket = sock;
      this.server = srv;
      this.id = id;
      this.createdOn = Util.millis();
      this.address = addr;
   }

   public void send(RelayPacket packet) {
      if (this.socket.isOpen()) {
         try {
            this.socket.send(RelayPacket.writePacket(packet, EaglerSPRelay.logger));
         } catch (IOException var3) {
            EaglerSPRelay.logger.debug("Error sending data to {}", this.socket.getAttachment());
            EaglerSPRelay.logger.debug((Throwable)var3);
            this.disconnect(4, "Internal Server Error");
            this.socket.close();
         }
      } else {
         EaglerSPRelay.logger.debug("WARNING: Tried to send data to {} after the connection closed.", this.socket.getAttachment());
      }

   }

   public boolean handle(RelayPacket packet) throws IOException {
      if (packet instanceof RelayPacket03ICECandidate) {
         if (LoginState.assertEquals(this, LoginState.RECIEVED_DESCRIPTION)) {
            this.state = LoginState.SENT_ICE_CANDIDATE;
            this.server.handleClientICECandidate(this, (RelayPacket03ICECandidate)packet);
            EaglerSPRelay.logger.debug("[{}][Client -> Relay -> Server] PKT 0x03: ICECandidate", this.socket.getAttachment());
         }

         return true;
      } else if (packet instanceof RelayPacket04Description) {
         if (LoginState.assertEquals(this, LoginState.INIT)) {
            this.state = LoginState.SENT_DESCRIPTION;
            this.server.handleClientDescription(this, (RelayPacket04Description)packet);
            EaglerSPRelay.logger.debug("[{}][Client -> Relay -> Server] PKT 0x04: Description", this.socket.getAttachment());
         }

         return true;
      } else if (packet instanceof RelayPacket05ClientSuccess) {
         if (LoginState.assertEquals(this, LoginState.RECIEVED_ICE_CANIDATE)) {
            this.state = LoginState.FINISHED;
            this.server.handleClientSuccess(this, (RelayPacket05ClientSuccess)packet);
            EaglerSPRelay.logger.debug("[{}][Client -> Relay -> Server] PKT 0x05: ClientSuccess", this.socket.getAttachment());
            this.disconnect(0, "Successful connection");
         }

         return true;
      } else if (packet instanceof RelayPacket06ClientFailure) {
         if (LoginState.assertEquals(this, LoginState.RECIEVED_ICE_CANIDATE)) {
            this.state = LoginState.FINISHED;
            this.server.handleClientFailure(this, (RelayPacket06ClientFailure)packet);
            EaglerSPRelay.logger.debug("[{}][Client -> Relay -> Server] PKT 0x05: ClientFailure", this.socket.getAttachment());
            this.disconnect(1, "Failed connection");
         }

         return true;
      } else {
         return false;
      }
   }

   public void handleServerICECandidate(RelayPacket03ICECandidate desc) {
      this.send(new RelayPacket03ICECandidate("", desc.candidate));
   }

   public void handleServerDescription(RelayPacket04Description desc) {
      this.send(new RelayPacket04Description("", desc.description));
   }

   public void handleServerDisconnectClient(RelayPacketFEDisconnectClient packet) {
      this.disconnect(packet.code, packet.reason);
   }

   public void disconnect(int code, String reason) {
      RelayPacket pkt = new RelayPacketFEDisconnectClient(this.id, code, reason);
      if (!this.serverNotifiedOfClose) {
         if (code != 0) {
            this.server.send(pkt);
         }

         this.serverNotifiedOfClose = true;
      }

      if (this.socket.isOpen()) {
         this.send(pkt);
         this.socket.close();
      }

      EaglerSPRelay.logger.debug("[{}][Relay -> Client] PKT 0xFE: #{} {}", this.socket.getAttachment(), code, reason);
   }

   public static String generateClientId() {
      Random r = new Random();
      char[] ret = new char[16];

      for(int i = 0; i < ret.length; ++i) {
         ret[i] = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ".charAt(r.nextInt("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ".length()));
      }

      return new String(ret);
   }
}
