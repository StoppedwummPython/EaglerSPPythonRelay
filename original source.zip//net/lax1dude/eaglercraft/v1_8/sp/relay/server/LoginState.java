package net.lax1dude.eaglercraft.v1_8.sp.relay.server;

public enum LoginState {
   INIT,
   SENT_ICE_CANDIDATE,
   RECIEVED_ICE_CANIDATE,
   SENT_DESCRIPTION,
   RECIEVED_DESCRIPTION,
   FINISHED;

   public static boolean assertEquals(EaglerSPClient client, LoginState state) {
      if (client.state != state) {
         String msg = "client is in state " + client.state.name() + " when it was supposed to be " + state.name();
         client.disconnect(3, msg);
         EaglerSPRelay.logger.debug("[{}][Relay -> Client] PKT 0xFE: TYPE_INVALID_OPERATION: {}", (String)client.socket.getAttachment(), msg);
         return false;
      } else {
         return true;
      }
   }

   // $FF: synthetic method
   private static LoginState[] $values() {
      return new LoginState[]{INIT, SENT_ICE_CANDIDATE, RECIEVED_ICE_CANIDATE, SENT_DESCRIPTION, RECIEVED_DESCRIPTION, FINISHED};
   }
}
