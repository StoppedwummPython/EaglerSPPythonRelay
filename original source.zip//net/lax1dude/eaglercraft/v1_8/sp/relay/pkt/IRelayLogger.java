package net.lax1dude.eaglercraft.v1_8.sp.relay.pkt;

public interface IRelayLogger {
   void debug(String var1, Object... var2);

   void info(String var1, Object... var2);

   void warn(String var1, Object... var2);

   void error(String var1, Object... var2);

   void error(Throwable var1);
}
