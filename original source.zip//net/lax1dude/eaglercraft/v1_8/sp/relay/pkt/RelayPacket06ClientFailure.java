package net.lax1dude.eaglercraft.v1_8.sp.relay.pkt;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class RelayPacket06ClientFailure extends RelayPacket {
   public String clientId;

   public RelayPacket06ClientFailure() {
   }

   public RelayPacket06ClientFailure(String clientId) {
      this.clientId = clientId;
   }

   public void read(DataInputStream input) throws IOException {
      this.clientId = readASCII8(input);
   }

   public void write(DataOutputStream output) throws IOException {
      writeASCII8(output, this.clientId);
   }

   public int packetLength() {
      return 1 + this.clientId.length();
   }
}
