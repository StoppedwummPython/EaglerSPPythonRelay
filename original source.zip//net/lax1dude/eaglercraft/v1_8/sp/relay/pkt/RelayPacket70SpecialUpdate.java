package net.lax1dude.eaglercraft.v1_8.sp.relay.pkt;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class RelayPacket70SpecialUpdate extends RelayPacket {
   public static final int OPERATION_UPDATE_CERTIFICATE = 105;
   public int operation;
   public byte[] updatePacket;

   public RelayPacket70SpecialUpdate() {
   }

   public RelayPacket70SpecialUpdate(int operation, byte[] updatePacket) {
      this.operation = operation;
      this.updatePacket = updatePacket;
   }

   public void read(DataInputStream input) throws IOException {
      this.operation = input.read();
      this.updatePacket = new byte[input.readUnsignedShort()];
      input.read(this.updatePacket);
   }

   public void write(DataOutputStream output) throws IOException {
      output.write(this.operation);
      output.writeShort(this.updatePacket.length);
      output.write(this.updatePacket);
   }

   public int packetLength() {
      return 3 + this.updatePacket.length;
   }
}
