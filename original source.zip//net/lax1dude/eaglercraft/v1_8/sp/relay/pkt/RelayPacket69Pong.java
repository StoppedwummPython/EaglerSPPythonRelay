package net.lax1dude.eaglercraft.v1_8.sp.relay.pkt;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class RelayPacket69Pong extends RelayPacket {
   public int protcolVersion;
   public String comment;
   public String brand;

   public RelayPacket69Pong(int protcolVersion, String comment, String brand) {
      if (comment.length() > 255) {
         comment = comment.substring(0, 256);
      }

      this.protcolVersion = protcolVersion;
      this.comment = comment;
      this.brand = brand;
   }

   public RelayPacket69Pong() {
   }

   public void write(DataOutputStream output) throws IOException {
      output.write(this.protcolVersion);
      writeASCII8(output, this.comment);
      writeASCII8(output, this.brand);
   }

   public void read(DataInputStream output) throws IOException {
      this.protcolVersion = output.read();
      this.comment = readASCII8(output);
      this.brand = readASCII8(output);
   }

   public int packetLength() {
      return 3 + this.comment.length() + this.brand.length();
   }
}
