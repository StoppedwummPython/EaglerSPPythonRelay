package net.lax1dude.eaglercraft.v1_8.sp.relay.pkt;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;

public class RelayPacket {
   private static final Map<Integer, Class<? extends RelayPacket>> definedPacketClasses = new HashMap();
   private static final Map<Integer, Supplier<? extends RelayPacket>> definedPacketCtors = new HashMap();
   private static final Map<Class<? extends RelayPacket>, Integer> definedPacketIds = new HashMap();

   private static void register(int id, Class<? extends RelayPacket> clazz, Supplier<? extends RelayPacket> ctor) {
      definedPacketClasses.put(id, clazz);
      definedPacketCtors.put(id, ctor);
      definedPacketIds.put(clazz, id);
   }

   public static RelayPacket readPacket(DataInputStream input, IRelayLogger logger) throws IOException {
      int i = input.read();
      Supplier<? extends RelayPacket> ctor = (Supplier)definedPacketCtors.get(i);
      if (ctor == null) {
         throw new IOException("Unknown packet type: " + i);
      } else {
         RelayPacket pkt = (RelayPacket)ctor.get();
         pkt.read(input);
         int j = input.available();
         if (j > 0) {
            throw new IOException("Packet type " + i + " had " + j + " remaining bytes");
         } else {
            return pkt;
         }
      }
   }

   public static byte[] writePacket(RelayPacket packet, IRelayLogger logger) throws IOException {
      Integer i = (Integer)definedPacketIds.get(packet.getClass());
      if (i != null) {
         int len = packet.packetLength();
         ByteArrayOutputStream bao = len == -1 ? new ByteArrayOutputStream() : new ByteArrayOutputStream(len + 1);
         bao.write(i);
         packet.write(new DataOutputStream(bao));
         byte[] ret = bao.toByteArray();
         if (len != -1 && ret.length != len + 1) {
            logger.debug("writePacket buffer for packet {} {} by {} bytes", packet.getClass().getSimpleName(), len + 1 < ret.length ? "overflowed" : "underflowed", len + 1 < ret.length ? ret.length - len - 1 : len + 1 - ret.length);
         }

         return ret;
      } else {
         throw new IOException("Unknown packet type: " + packet.getClass().getSimpleName());
      }
   }

   public void read(DataInputStream input) throws IOException {
   }

   public void write(DataOutputStream output) throws IOException {
   }

   public int packetLength() {
      return -1;
   }

   public static String readASCII(InputStream is, int len) throws IOException {
      char[] ret = new char[len];

      for(int i = 0; i < len; ++i) {
         int j = is.read();
         if (j < 0) {
            throw new EOFException();
         }

         ret[i] = (char)j;
      }

      return new String(ret);
   }

   public static void writeASCII(OutputStream is, String txt) throws IOException {
      int i = 0;

      for(int l = txt.length(); i < l; ++i) {
         is.write(txt.charAt(i));
      }

   }

   public static String readASCII8(InputStream is) throws IOException {
      int i = is.read();
      if (i < 0) {
         throw new EOFException();
      } else {
         return readASCII(is, i);
      }
   }

   public static void writeASCII8(OutputStream is, String txt) throws IOException {
      if (txt == null) {
         is.write(0);
      } else {
         int l = txt.length();
         is.write(l);

         for(int i = 0; i < l; ++i) {
            is.write(txt.charAt(i));
         }
      }

   }

   public static String readASCII16(InputStream is) throws IOException {
      int hi = is.read();
      int lo = is.read();
      if (hi >= 0 && lo >= 0) {
         return readASCII(is, hi << 8 | lo);
      } else {
         throw new EOFException();
      }
   }

   public static void writeASCII16(OutputStream is, String txt) throws IOException {
      if (txt == null) {
         is.write(0);
         is.write(0);
      } else {
         int l = txt.length();
         is.write(l >>> 8 & 255);
         is.write(l & 255);

         for(int i = 0; i < l; ++i) {
            is.write(txt.charAt(i));
         }
      }

   }

   public static byte[] readBytes16(InputStream is) throws IOException {
      int hi = is.read();
      int lo = is.read();
      if (hi >= 0 && lo >= 0) {
         byte[] ret = new byte[hi << 8 | lo];
         is.read(ret);
         return ret;
      } else {
         throw new EOFException();
      }
   }

   public static void writeBytes16(OutputStream is, byte[] arr) throws IOException {
      if (arr == null) {
         is.write(0);
         is.write(0);
      } else {
         is.write(arr.length >>> 8 & 255);
         is.write(arr.length & 255);

         for(int i = 0; i < arr.length; ++i) {
            is.write(arr[i]);
         }
      }

   }

   public static byte[] toASCIIBin(String txt) {
      if (txt == null) {
         return new byte[0];
      } else {
         byte[] ret = new byte[txt.length()];

         for(int i = 0; i < ret.length; ++i) {
            ret[i] = (byte)txt.charAt(i);
         }

         return ret;
      }
   }

   public static String toASCIIStr(byte[] bin) {
      char[] charRet = new char[bin.length];

      for(int i = 0; i < charRet.length; ++i) {
         charRet[i] = (char)(bin[i] & 255);
      }

      return new String(charRet);
   }

   static {
      register(0, RelayPacket00Handshake.class, RelayPacket00Handshake::new);
      register(1, RelayPacket01ICEServers.class, RelayPacket01ICEServers::new);
      register(2, RelayPacket02NewClient.class, RelayPacket02NewClient::new);
      register(3, RelayPacket03ICECandidate.class, RelayPacket03ICECandidate::new);
      register(4, RelayPacket04Description.class, RelayPacket04Description::new);
      register(5, RelayPacket05ClientSuccess.class, RelayPacket05ClientSuccess::new);
      register(6, RelayPacket06ClientFailure.class, RelayPacket06ClientFailure::new);
      register(7, RelayPacket07LocalWorlds.class, RelayPacket07LocalWorlds::new);
      register(105, RelayPacket69Pong.class, RelayPacket69Pong::new);
      register(112, RelayPacket70SpecialUpdate.class, RelayPacket70SpecialUpdate::new);
      register(254, RelayPacketFEDisconnectClient.class, RelayPacketFEDisconnectClient::new);
      register(255, RelayPacketFFErrorCode.class, RelayPacketFFErrorCode::new);
   }
}
