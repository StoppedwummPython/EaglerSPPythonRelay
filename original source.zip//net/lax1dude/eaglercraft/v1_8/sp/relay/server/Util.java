package net.lax1dude.eaglercraft.v1_8.sp.relay.server;

import java.net.InetSocketAddress;

public class Util {
   public static void sleep(long millis) {
      try {
         Thread.sleep(millis);
      } catch (InterruptedException var3) {
      }

   }

   public static String sock2String(InetSocketAddress sock) {
      return sock.getAddress().getHostAddress() + ":" + sock.getPort();
   }

   public static long millis() {
      return System.nanoTime() / 1000000L;
   }
}
