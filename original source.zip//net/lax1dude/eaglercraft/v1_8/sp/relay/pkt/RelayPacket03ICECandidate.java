package net.lax1dude.eaglercraft.v1_8.sp.relay.pkt;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class RelayPacket03ICECandidate extends RelayPacket {
   public String peerId;
   public byte[] candidate;

   public RelayPacket03ICECandidate() {
   }

   public RelayPacket03ICECandidate(String peerId, String desc) {
      this.peerId = peerId;
      this.candidate = toASCIIBin(desc);
   }

   public RelayPacket03ICECandidate(String peerId, byte[] desc) {
      this.peerId = peerId;
      this.candidate = desc;
   }

   public void read(DataInputStream input) throws IOException {
      this.peerId = readASCII8(input);
      this.candidate = readBytes16(input);
   }

   public void write(DataOutputStream output) throws IOException {
      writeASCII8(output, this.peerId);
      writeBytes16(output, this.candidate);
   }

   public String getCandidateString() {
      return this.candidate == null ? null : toASCIIStr(this.candidate);
   }

   public int packetLength() {
      return 1 + this.peerId.length() + 2 + this.candidate.length;
   }
}
