package net.lax1dude.eaglercraft.v1_8.sp.relay.pkt;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class RelayPacketFFErrorCode extends RelayPacket {
   public static final int TYPE_INTERNAL_ERROR = 0;
   public static final int TYPE_PROTOCOL_VERSION = 1;
   public static final int TYPE_INVALID_PACKET = 2;
   public static final int TYPE_ILLEGAL_OPERATION = 3;
   public static final int TYPE_CODE_LENGTH = 4;
   public static final int TYPE_INCORRECT_CODE = 5;
   public static final int TYPE_SERVER_DISCONNECTED = 6;
   public static final int TYPE_UNKNOWN_CLIENT = 7;
   public static final String[] packetTypes = new String[8];
   public int code;
   public String desc;

   public static String code2string(int i) {
      return i < 0 && i >= packetTypes.length ? "UNKNOWN" : packetTypes[i];
   }

   public RelayPacketFFErrorCode() {
   }

   public RelayPacketFFErrorCode(int code, String desc) {
      this.code = code;
      this.desc = desc;
   }

   public void read(DataInputStream input) throws IOException {
      this.code = input.read();
      this.desc = readASCII16(input);
   }

   public void write(DataOutputStream input) throws IOException {
      input.write(this.code);
      writeASCII16(input, this.desc);
   }

   public int packetLength() {
      return 3 + this.desc.length();
   }

   static {
      packetTypes[0] = "TYPE_INTERNAL_ERROR";
      packetTypes[1] = "TYPE_PROTOCOL_VERSION";
      packetTypes[2] = "TYPE_INVALID_PACKET";
      packetTypes[3] = "TYPE_ILLEGAL_OPERATION";
      packetTypes[4] = "TYPE_CODE_LENGTH";
      packetTypes[5] = "TYPE_INCORRECT_CODE";
      packetTypes[6] = "TYPE_SERVER_DISCONNECTED";
      packetTypes[7] = "TYPE_UNKNOWN_CLIENT";
   }
}
