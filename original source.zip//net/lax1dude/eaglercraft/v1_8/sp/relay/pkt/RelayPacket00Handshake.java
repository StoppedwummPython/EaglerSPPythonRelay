package net.lax1dude.eaglercraft.v1_8.sp.relay.pkt;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class RelayPacket00Handshake extends RelayPacket {
   public int connectionType = 0;
   public int connectionVersion = 1;
   public String connectionCode = null;

   public RelayPacket00Handshake() {
   }

   public RelayPacket00Handshake(int connectionType, int connectionVersion, String connectionCode) {
      this.connectionType = connectionType;
      this.connectionVersion = connectionVersion;
      this.connectionCode = connectionCode;
   }

   public void read(DataInputStream input) throws IOException {
      this.connectionType = input.read();
      this.connectionVersion = input.read();
      this.connectionCode = RelayPacket.readASCII8(input);
   }

   public void write(DataOutputStream output) throws IOException {
      output.write(this.connectionType);
      output.write(this.connectionVersion);
      RelayPacket.writeASCII8(output, this.connectionCode);
   }

   public int packetLength() {
      return 2 + (this.connectionCode != null ? 1 + this.connectionCode.length() : 0);
   }
}
