package net.lax1dude.eaglercraft.v1_8.sp.relay.server;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import net.lax1dude.eaglercraft.v1_8.sp.relay.pkt.RelayPacket;
import net.lax1dude.eaglercraft.v1_8.sp.relay.pkt.RelayPacket00Handshake;
import net.lax1dude.eaglercraft.v1_8.sp.relay.pkt.RelayPacket01ICEServers;
import net.lax1dude.eaglercraft.v1_8.sp.relay.pkt.RelayPacket07LocalWorlds;
import net.lax1dude.eaglercraft.v1_8.sp.relay.pkt.RelayPacket69Pong;
import net.lax1dude.eaglercraft.v1_8.sp.relay.pkt.RelayPacketFEDisconnectClient;
import net.lax1dude.eaglercraft.v1_8.sp.relay.pkt.RelayPacketFFErrorCode;
import org.java_websocket.WebSocket;
import org.java_websocket.handshake.ClientHandshake;
import org.java_websocket.server.WebSocketServer;

public class EaglerSPRelay extends WebSocketServer {
   public static EaglerSPRelay instance;
   public static final EaglerSPRelayConfig config = new EaglerSPRelayConfig();
   private static RateLimiter pingRateLimiter = null;
   private static RateLimiter worldRateLimiter = null;
   public static final DebugLogger logger = DebugLogger.getLogger("EaglerSPRelay");
   private static final Map<String, EaglerSPClient> clientIds = new HashMap();
   private static final Map<String, EaglerSPServer> serverCodes = new HashMap();
   private static final ConcurrentMap<WebSocket, EaglerSPRelay.PendingConnection> pendingConnections = new ConcurrentHashMap();
   private static final ConcurrentMap<WebSocket, EaglerSPClient> clientConnections = new ConcurrentHashMap();
   private static final ConcurrentMap<WebSocket, EaglerSPServer> serverConnections = new ConcurrentHashMap();
   private static final ReadWriteLock clientAddressSetsLock = new ReentrantReadWriteLock();
   private static final Map<String, List<EaglerSPClient>> clientAddressSets = new HashMap();
   private static final ReadWriteLock serverAddressSetsLock = new ReentrantReadWriteLock();
   private static final Map<String, List<EaglerSPServer>> serverAddressSets = new HashMap();

   public static void main(String[] args) throws IOException, InterruptedException {
      for(int i = 0; i < args.length; ++i) {
         if (args[i].equalsIgnoreCase("--debug")) {
            DebugLogger.enableDebugLogging(DebugLogger.Level.DEBUG);
            logger.debug("Debug logging enabled");
         }
      }

      logger.info("Starting EaglerSPRelay version {}...", "1.4");
      config.load(new File("relayConfig.ini"));
      if (config.isPingRateLimitEnable()) {
         pingRateLimiter = new RateLimiter(config.getPingRateLimitPeriod() * 1000, config.getPingRateLimitLimit(), config.getPingRateLimitLockoutLimit(), config.getPingRateLimitLockoutDuration() * 1000);
      }

      if (config.isWorldRateLimitEnable()) {
         worldRateLimiter = new RateLimiter(config.getWorldRateLimitPeriod() * 1000, config.getWorldRateLimitLimit(), config.getWorldRateLimitLockoutLimit(), config.getWorldRateLimitLockoutDuration() * 1000);
      }

      EaglerSPRelayConfigRelayList.loadRelays(new File("relays.txt"));
      logger.info("Starting WebSocket Server...");
      instance = new EaglerSPRelay(new InetSocketAddress(config.getAddress(), config.getPort()));
      instance.setConnectionLostTimeout(20);
      instance.setReuseAddr(true);
      instance.start();
      Thread tickThread = new Thread(() -> {
         int rateLimitUpdateCounter = 0;
         List<WebSocket> pendingToClose = new LinkedList();
         LinkedList clientToClose = new LinkedList();

         while(true) {
            try {
               long millis = Util.millis();
               pendingToClose.clear();
               clientToClose.clear();
               pendingConnections.entrySet().forEach((etr) -> {
                  if (millis - ((EaglerSPRelay.PendingConnection)etr.getValue()).openTime > 1000L) {
                     pendingToClose.add((WebSocket)etr.getKey());
                  }

               });
               clientConnections.values().forEach((clxx) -> {
                  if (millis - clxx.createdOn > 15000L) {
                     clientToClose.add(clxx);
                  }

               });
               Iterator var5;
               if (!pendingToClose.isEmpty()) {
                  var5 = pendingToClose.iterator();

                  while(var5.hasNext()) {
                     WebSocket cl = (WebSocket)var5.next();
                     pendingConnections.remove(cl);
                     cl.close();
                  }

                  pendingToClose.clear();
               }

               if (!clientToClose.isEmpty()) {
                  var5 = clientToClose.iterator();

                  while(var5.hasNext()) {
                     EaglerSPClient clx = (EaglerSPClient)var5.next();
                     clx.disconnect(2, "Took too long to connect!");
                  }

                  clientToClose.clear();
               }

               ++rateLimitUpdateCounter;
               if (rateLimitUpdateCounter > 300) {
                  if (pingRateLimiter != null) {
                     pingRateLimiter.update();
                  }

                  if (worldRateLimiter != null) {
                     worldRateLimiter.update();
                  }

                  rateLimitUpdateCounter = 0;
               }
            } catch (Throwable var7) {
               logger.error("Error in update loop!");
               logger.error(var7);
            }

            Util.sleep(100L);
         }
      }, "Relay Tick");
      tickThread.setDaemon(true);
      tickThread.start();
      BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

      while(true) {
         while(true) {
            String s;
            while((s = reader.readLine()) != null) {
               s = s.trim();
               if (!s.equalsIgnoreCase("stop") && !s.equalsIgnoreCase("end")) {
                  if (s.equalsIgnoreCase("reset")) {
                     logger.info("Clearing all ratelimits");
                     if (pingRateLimiter != null) {
                        pingRateLimiter.reset();
                     }

                     if (worldRateLimiter != null) {
                        worldRateLimiter.reset();
                     }
                  } else {
                     logger.info("Unknown command: {}", s);
                     logger.info("Type 'stop' to exit" + (worldRateLimiter == null && pingRateLimiter == null ? "" : ", 'reset' to clear ratelimits"));
                  }
               } else {
                  logger.info("Shutting down...");
                  instance.stop();
                  System.exit(0);
               }
            }

            return;
         }
      }
   }

   private EaglerSPRelay(InetSocketAddress addr) {
      super(addr);
   }

   public void onStart() {
      logger.info("Listening on {}", this.getAddress());
      logger.info("Type 'stop' to exit" + (worldRateLimiter == null && pingRateLimiter == null ? "" : ", 'reset' to clear ratelimits"));
   }

   public void onOpen(WebSocket arg0, ClientHandshake arg1) {
      if (!config.getIsWhitelisted(arg1.getFieldValue("origin"))) {
         arg0.close();
      } else {
         long millis = Util.millis();
         String addr;
         if (config.isEnableRealIpHeader() && arg1.hasFieldValue(config.getRealIPHeaderName())) {
            addr = arg1.getFieldValue(config.getRealIPHeaderName()).toLowerCase();
         } else {
            addr = arg0.getRemoteSocketAddress().getAddress().getHostAddress().toLowerCase();
         }

         int[] totalCons = new int[1];
         pendingConnections.values().forEach((con) -> {
            if (con.address.equals(addr)) {
               int var10002 = totalCons[0]++;
            }

         });
         clientAddressSetsLock.readLock().lock();

         try {
            List<EaglerSPClient> lst = (List)clientAddressSets.get(addr);
            if (lst != null) {
               totalCons[0] += lst.size();
            }
         } finally {
            clientAddressSetsLock.readLock().unlock();
         }

         if (totalCons[0] >= config.getConnectionsPerIP()) {
            logger.debug("[{}]: Too many connections are open on this address", arg0.getAttachment());
            arg0.send(RelayPacketFEDisconnectClient.ratelimitPacketTooMany);
            arg0.close();
         } else {
            arg0.setAttachment(addr);
            EaglerSPRelay.PendingConnection waiting = new EaglerSPRelay.PendingConnection(millis, addr);
            logger.debug("[{}]: Connection opened", arg0.getRemoteSocketAddress());
            pendingConnections.put(arg0, waiting);
         }
      }
   }

   public void onMessage(WebSocket arg0, ByteBuffer arg1) {
      DataInputStream sid = new DataInputStream(new ByteBufferInputStream(arg1));
      EaglerSPRelay.PendingConnection waiting = (EaglerSPRelay.PendingConnection)pendingConnections.remove(arg0);

      try {
         RelayPacket pkt = RelayPacket.readPacket(sid, logger);
         if (waiting != null) {
            if (pkt instanceof RelayPacket00Handshake) {
               RelayPacket00Handshake ipkt = (RelayPacket00Handshake)pkt;
               if (ipkt.connectionVersion != 1) {
                  logger.debug("[{}]: Connected with unsupported protocol version: {} (supported version: {})", arg0.getAttachment(), ipkt.connectionVersion, 1);
                  if (ipkt.connectionVersion < 1) {
                     arg0.send(RelayPacket.writePacket(new RelayPacketFFErrorCode(1, "Outdated Client! (v1 req)"), logger));
                  } else {
                     arg0.send(RelayPacket.writePacket(new RelayPacketFFErrorCode(1, "Outdated Server! (still on v1)"), logger));
                  }

                  arg0.close();
                  return;
               }

               String id;
               EaglerSPServer srv;
               if (ipkt.connectionType == 1) {
                  if (!this.rateLimit(worldRateLimiter, arg0, waiting.address)) {
                     logger.debug("[{}]: Got world ratelimited", arg0.getAttachment());
                     return;
                  }

                  boolean fuck = false;
                  serverAddressSetsLock.readLock().lock();

                  try {
                     List<EaglerSPServer> lst = (List)serverAddressSets.get(waiting.address);
                     if (lst != null && lst.size() >= config.getWorldsPerIP()) {
                        fuck = true;
                     }
                  } finally {
                     serverAddressSetsLock.readLock().unlock();
                  }

                  if (fuck) {
                     logger.debug("[{}]: Too many worlds are open on this address", arg0.getAttachment());
                     arg0.send(RelayPacketFEDisconnectClient.ratelimitPacketTooMany);
                     arg0.close();
                     return;
                  }

                  logger.debug("[{}]: Connected as a server", arg0.getAttachment());
                  srv = null;
                  id = null;
                  synchronized(serverCodes) {
                     int j = 0;

                     while(true) {
                        ++j;
                        if (j > 20) {
                           logger.error("Error: relay is running out of codes!");
                           logger.error("Closing connection to {}", arg0.getAttachment());
                           break;
                        } else {
                           id = config.generateCode();
                           if (!serverCodes.containsKey(id)) {
                              srv = new EaglerSPServer(arg0, id, ipkt.connectionCode, waiting.address);
                              serverCodes.put(id, srv);
                              break;
                           }
                        }
                     }
                  }

                  if (srv == null) {
                     arg0.send(RelayPacket.writePacket(new RelayPacketFFErrorCode(0, "Internal Server Error"), logger));
                     arg0.close();
                     return;
                  }

                  ipkt.connectionCode = id;
                  arg0.send(RelayPacket.writePacket(ipkt, logger));
                  logger.debug("[{}][Relay -> Server] PKT 0x00: Assign join code: {}", arg0.getAttachment(), id);
                  serverConnections.put(arg0, srv);
                  serverAddressSetsLock.writeLock().lock();

                  try {
                     List<EaglerSPServer> lst = (List)serverAddressSets.get(srv.serverAddress);
                     if (lst == null) {
                        lst = new ArrayList();
                        serverAddressSets.put(srv.serverAddress, lst);
                     }

                     ((List)lst).add(srv);
                  } finally {
                     serverAddressSetsLock.writeLock().unlock();
                  }

                  srv.send(new RelayPacket01ICEServers(EaglerSPRelayConfigRelayList.relayServers));
                  logger.debug("[{}][Relay -> Server] PKT 0x01: Send ICE server list to server", arg0.getAttachment());
               } else {
                  if (!this.rateLimit(pingRateLimiter, arg0, waiting.address)) {
                     logger.debug("[{}]: Got ping ratelimited", arg0.getAttachment());
                     return;
                  }

                  if (ipkt.connectionType == 2) {
                     String code = ipkt.connectionCode;
                     logger.debug("[{}]: Connected as a client, requested server code: {}", arg0.getAttachment(), code);
                     if (code.length() != config.getCodeLength()) {
                        logger.debug("The code '{}' is invalid because it's the wrong length, disconnecting", code);
                        arg0.send(RelayPacket.writePacket(new RelayPacketFFErrorCode(4, "The join code is the wrong length, it should be " + config.getCodeLength() + " chars long"), logger));
                        arg0.close();
                     } else {
                        if (!config.isCodeMixCase()) {
                           code = code.toLowerCase();
                        }

                        synchronized(serverCodes) {
                           srv = (EaglerSPServer)serverCodes.get(code);
                        }

                        if (srv == null) {
                           arg0.send(RelayPacket.writePacket(new RelayPacketFFErrorCode(5, "Invalid code, no LAN world found!"), logger));
                           arg0.close();
                           return;
                        }

                        EaglerSPClient cl;
                        synchronized(clientIds) {
                           do {
                              id = EaglerSPClient.generateClientId();
                           } while(clientIds.containsKey(id));

                           cl = new EaglerSPClient(arg0, srv, id, waiting.address);
                           clientIds.put(id, cl);
                        }

                        ipkt.connectionCode = id;
                        arg0.send(RelayPacket.writePacket(ipkt, logger));
                        srv.handleNewClient(cl);
                        clientConnections.put(arg0, cl);
                        clientAddressSetsLock.writeLock().lock();

                        try {
                           List<EaglerSPClient> lst = (List)clientAddressSets.get(cl.address);
                           if (lst == null) {
                              lst = new ArrayList();
                              clientAddressSets.put(cl.address, lst);
                           }

                           ((List)lst).add(cl);
                        } finally {
                           clientAddressSetsLock.writeLock().unlock();
                        }

                        cl.send(new RelayPacket01ICEServers(EaglerSPRelayConfigRelayList.relayServers));
                        logger.debug("[{}][Relay -> Client] PKT 0x01: Send ICE server list to client", arg0.getAttachment());
                     }
                  } else if (ipkt.connectionType == 3) {
                     logger.debug("[{}]: Pinging the server", arg0.getAttachment());
                     arg0.send(RelayPacket.writePacket(new RelayPacket69Pong(1, config.getComment(), "lax1dude"), logger));
                     arg0.close();
                  } else if (ipkt.connectionType == 4) {
                     logger.debug("[{}]: Polling the server for other worlds", arg0.getAttachment());
                     if (config.isEnableShowLocals()) {
                        arg0.send(RelayPacket.writePacket(new RelayPacket07LocalWorlds(this.getLocalWorlds(waiting.address)), logger));
                     } else {
                        arg0.send(RelayPacket.writePacket(new RelayPacket07LocalWorlds((List)null), logger));
                     }

                     arg0.close();
                  } else {
                     logger.debug("[{}]: Unknown connection type: {}", arg0.getAttachment(), ipkt.connectionType);
                     arg0.send(RelayPacket.writePacket(new RelayPacketFFErrorCode(3, "Unexpected Init Packet"), logger));
                     arg0.close();
                  }
               }
            } else {
               logger.debug("[{}]: Pending connection did not send a 0x00 packet to identify as a client or server", arg0.getAttachment());
               arg0.send(RelayPacket.writePacket(new RelayPacketFFErrorCode(3, "Unexpected Init Packet"), logger));
               arg0.close();
            }
         } else {
            EaglerSPServer srv = (EaglerSPServer)serverConnections.get(arg0);
            if (srv != null) {
               if (!srv.handle(pkt)) {
                  logger.debug("[{}]: Server sent invalid packet: {}", arg0.getAttachment(), pkt.getClass().getSimpleName());
                  arg0.send(RelayPacket.writePacket(new RelayPacketFFErrorCode(2, "Invalid Packet Recieved"), logger));
                  arg0.close();
               }
            } else {
               EaglerSPClient cl = (EaglerSPClient)clientConnections.get(arg0);
               if (cl != null) {
                  if (!cl.handle(pkt)) {
                     logger.debug("[{}]: Client sent invalid packet: {}", arg0.getAttachment(), pkt.getClass().getSimpleName());
                     arg0.send(RelayPacket.writePacket(new RelayPacketFFErrorCode(2, "Invalid Packet Recieved"), logger));
                     arg0.close();
                  }
               } else {
                  logger.debug("[{}]: Connection has no client/server attached to it!", arg0.getAttachment());
                  arg0.send(RelayPacket.writePacket(new RelayPacketFFErrorCode(3, "Internal Server Error"), logger));
                  arg0.close();
               }
            }
         }
      } catch (Throwable var44) {
         logger.error("[{}]: Failed to handle binary frame: {}", arg0.getAttachment(), var44);
         arg0.close();
      }

   }

   public void onMessage(WebSocket arg0, String arg1) {
      logger.debug("[{}]: Sent a text frame, disconnecting", arg0.getAttachment());
      arg0.close();
   }

   public void onClose(WebSocket arg0, int arg1, String arg2, boolean arg3) {
      EaglerSPServer srv = (EaglerSPServer)serverConnections.remove(arg0);
      if (srv != null) {
         logger.debug("[{}]: Server closed, code: {}", arg0.getAttachment(), srv.code);
         synchronized(serverCodes) {
            serverCodes.remove(srv.code);
         }

         serverAddressSetsLock.writeLock().lock();

         try {
            List<EaglerSPServer> lst = (List)serverAddressSets.get(srv.serverAddress);
            if (lst != null) {
               lst.remove(srv);
               if (lst.size() == 0) {
                  serverAddressSets.remove(srv.serverAddress);
               }
            }
         } finally {
            serverAddressSetsLock.writeLock().unlock();
         }

         ArrayList clientList = new ArrayList();
         clientConnections.values().forEach((clx) -> {
            if (clx.server == srv) {
               clientList.add(clx);
            }

         });
         Iterator itr = clientList.iterator();

         while(itr.hasNext()) {
            EaglerSPClient cl = (EaglerSPClient)itr.next();
            logger.debug("[{}]: Disconnecting client: {} (id: {})", cl.socket.getAttachment(), cl.id);
            cl.socket.close();
         }
      } else {
         EaglerSPClient cl = (EaglerSPClient)clientConnections.remove(arg0);
         if (cl != null) {
            clientAddressSetsLock.writeLock().lock();

            try {
               List<EaglerSPClient> lst = (List)clientAddressSets.get(cl.address);
               if (lst != null) {
                  lst.remove(cl);
                  if (lst.size() == 0) {
                     clientAddressSets.remove(cl.address);
                  }
               }
            } finally {
               clientAddressSetsLock.writeLock().unlock();
            }

            logger.debug("[{}]: Client closed, id: {}", arg0.getAttachment(), cl.id);
            synchronized(clientIds) {
               clientIds.remove(cl.id);
            }

            cl.server.handleClientDisconnect(cl);
         } else {
            logger.debug("[{}]: Connection Closed", arg0.getAttachment());
         }
      }

   }

   public void onError(WebSocket arg0, Exception arg1) {
      logger.error("[{}]: Exception thrown: {}", arg0 == null ? "SERVER" : arg0.getAttachment(), arg1.toString());
      logger.debug((Throwable)arg1);
      if (arg0 != null) {
         arg0.close();
      }

   }

   public void stop() throws InterruptedException {
      Thread killServer = new Thread(() -> {
         try {
            Thread.sleep(5000L);
         } catch (InterruptedException var1) {
         }

         logger.error("WebSocketServer stopped, but the process is still running, calling System.exit to hopefully restart!");
         System.exit(-1);
      }, "Terminator");
      killServer.setDaemon(true);
      killServer.start();
      super.stop();
   }

   private List<RelayPacket07LocalWorlds.LocalWorld> getLocalWorlds(String addr) {
      List<RelayPacket07LocalWorlds.LocalWorld> lst = new ArrayList();
      serverAddressSetsLock.readLock().lock();

      try {
         List<EaglerSPServer> srvs = (List)serverAddressSets.get(addr);
         if (srvs != null && srvs.size() > 0) {
            Iterator var4 = srvs.iterator();

            while(var4.hasNext()) {
               EaglerSPServer s = (EaglerSPServer)var4.next();
               if (!s.serverHidden) {
                  lst.add(new RelayPacket07LocalWorlds.LocalWorld(s.serverName, s.code));
               }
            }
         }
      } finally {
         serverAddressSetsLock.readLock().unlock();
      }

      return lst;
   }

   private boolean rateLimit(RateLimiter limiter, WebSocket sock, String addr) {
      if (limiter != null) {
         RateLimiter.RateLimit l = limiter.limit(addr);
         if (l == RateLimiter.RateLimit.NONE) {
            return true;
         } else if (l == RateLimiter.RateLimit.LIMIT) {
            sock.send(RelayPacketFEDisconnectClient.ratelimitPacketBlock);
            sock.close();
            return false;
         } else if (l == RateLimiter.RateLimit.LIMIT_NOW_LOCKOUT) {
            sock.send(RelayPacketFEDisconnectClient.ratelimitPacketBlockLock);
            sock.close();
            return false;
         } else if (l == RateLimiter.RateLimit.LOCKOUT) {
            sock.close();
            return false;
         } else {
            return true;
         }
      } else {
         return true;
      }
   }

   private static class PendingConnection {
      private final long openTime;
      private final String address;

      public PendingConnection(long openTime, String address) {
         this.openTime = openTime;
         this.address = address;
      }
   }
}
