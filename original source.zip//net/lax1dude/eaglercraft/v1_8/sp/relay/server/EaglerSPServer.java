package net.lax1dude.eaglercraft.v1_8.sp.relay.server;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import net.lax1dude.eaglercraft.v1_8.sp.relay.pkt.RelayPacket;
import net.lax1dude.eaglercraft.v1_8.sp.relay.pkt.RelayPacket02NewClient;
import net.lax1dude.eaglercraft.v1_8.sp.relay.pkt.RelayPacket03ICECandidate;
import net.lax1dude.eaglercraft.v1_8.sp.relay.pkt.RelayPacket04Description;
import net.lax1dude.eaglercraft.v1_8.sp.relay.pkt.RelayPacket05ClientSuccess;
import net.lax1dude.eaglercraft.v1_8.sp.relay.pkt.RelayPacket06ClientFailure;
import net.lax1dude.eaglercraft.v1_8.sp.relay.pkt.RelayPacketFEDisconnectClient;
import net.lax1dude.eaglercraft.v1_8.sp.relay.pkt.RelayPacketFFErrorCode;
import org.java_websocket.WebSocket;

public class EaglerSPServer {
   public final WebSocket socket;
   public final String code;
   public final Map<String, EaglerSPClient> clients;
   public final String serverName;
   public final String serverAddress;
   public final boolean serverHidden;

   EaglerSPServer(WebSocket sock, String code, String serverName, String serverAddress) {
      this.socket = sock;
      this.code = code;
      this.clients = new HashMap();
      if (serverName.endsWith(";1")) {
         this.serverHidden = true;
         serverName = serverName.substring(0, serverName.length() - 2);
      } else if (serverName.endsWith(";0")) {
         this.serverHidden = false;
         serverName = serverName.substring(0, serverName.length() - 2);
      } else {
         this.serverHidden = false;
      }

      this.serverName = serverName;
      this.serverAddress = serverAddress;
   }

   public void send(RelayPacket packet) {
      if (this.socket.isOpen()) {
         try {
            this.socket.send(RelayPacket.writePacket(packet, EaglerSPRelay.logger));
         } catch (IOException var5) {
            EaglerSPRelay.logger.debug("Error sending data to {}", this.serverAddress);
            EaglerSPRelay.logger.debug((Throwable)var5);

            try {
               this.socket.send(RelayPacket.writePacket(new RelayPacketFFErrorCode(0, "Internal Server Error"), EaglerSPRelay.logger));
            } catch (IOException var4) {
            }

            this.socket.close();
         }
      } else {
         EaglerSPRelay.logger.debug("WARNING: Tried to send data to {} after the connection closed.", this.serverAddress);
      }

   }

   public boolean handle(RelayPacket _packet) throws IOException {
      EaglerSPClient cl;
      if (_packet instanceof RelayPacket03ICECandidate) {
         RelayPacket03ICECandidate packet = (RelayPacket03ICECandidate)_packet;
         synchronized(this.clients) {
            cl = (EaglerSPClient)this.clients.get(packet.peerId);
         }

         if (cl != null) {
            if (LoginState.assertEquals(cl, LoginState.SENT_ICE_CANDIDATE)) {
               cl.state = LoginState.RECIEVED_ICE_CANIDATE;
               cl.handleServerICECandidate(packet);
               EaglerSPRelay.logger.debug("[{}][Server -> Relay -> Client] PKT 0x03: ICECandidate", cl.socket.getAttachment());
            }
         } else {
            this.socket.send(RelayPacket.writePacket(new RelayPacketFFErrorCode(7, "Unknown Client ID: " + packet.peerId), EaglerSPRelay.logger));
         }

         return true;
      } else if (_packet instanceof RelayPacket04Description) {
         RelayPacket04Description packet = (RelayPacket04Description)_packet;
         synchronized(this.clients) {
            cl = (EaglerSPClient)this.clients.get(packet.peerId);
         }

         if (cl != null) {
            if (LoginState.assertEquals(cl, LoginState.SENT_DESCRIPTION)) {
               cl.state = LoginState.RECIEVED_DESCRIPTION;
               cl.handleServerDescription(packet);
               EaglerSPRelay.logger.debug("[{}][Server -> Relay -> Client] PKT 0x04: Description", cl.socket.getAttachment());
            }
         } else {
            this.socket.send(RelayPacket.writePacket(new RelayPacketFFErrorCode(7, "Unknown Client ID: " + packet.peerId), EaglerSPRelay.logger));
         }

         return true;
      } else if (_packet instanceof RelayPacketFEDisconnectClient) {
         RelayPacketFEDisconnectClient packet = (RelayPacketFEDisconnectClient)_packet;
         synchronized(this.clients) {
            cl = (EaglerSPClient)this.clients.get(packet.clientId);
         }

         if (cl != null) {
            cl.handleServerDisconnectClient(packet);
            EaglerSPRelay.logger.debug("[{}][Server -> Relay -> Client] PKT 0xFE: Disconnect: {}: {}", cl.socket.getAttachment(), packet.code, packet.reason);
         } else {
            this.socket.send(RelayPacket.writePacket(new RelayPacketFFErrorCode(7, "Unknown Client ID: " + packet.clientId), EaglerSPRelay.logger));
         }

         return true;
      } else {
         return false;
      }
   }

   public void handleNewClient(EaglerSPClient client) {
      synchronized(this.clients) {
         this.clients.put(client.id, client);
      }

      this.send(new RelayPacket02NewClient(client.id));
      EaglerSPRelay.logger.debug("[{}][Relay -> Server] PKT 0x02: Notify server of the client, id: {}", this.serverAddress, client.id);
   }

   public void handleClientDisconnect(EaglerSPClient client) {
      synchronized(this.clients) {
         this.clients.remove(client.id);
      }

      if (!client.serverNotifiedOfClose) {
         this.send(new RelayPacketFEDisconnectClient(client.id, 255, "End of stream"));
         client.serverNotifiedOfClose = true;
      }

   }

   public void handleClientICECandidate(EaglerSPClient client, RelayPacket03ICECandidate packet) {
      this.send(new RelayPacket03ICECandidate(client.id, packet.candidate));
   }

   public void handleClientDescription(EaglerSPClient client, RelayPacket04Description packet) {
      this.send(new RelayPacket04Description(client.id, packet.description));
   }

   public void handleClientSuccess(EaglerSPClient client, RelayPacket05ClientSuccess packet) {
      this.send(new RelayPacket05ClientSuccess(client.id));
   }

   public void handleClientFailure(EaglerSPClient client, RelayPacket06ClientFailure packet) {
      this.send(new RelayPacket06ClientFailure(client.id));
   }
}
