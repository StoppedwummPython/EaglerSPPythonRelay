package net.lax1dude.eaglercraft.v1_8.sp.relay.pkt;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;

public class RelayPacketFEDisconnectClient extends RelayPacket {
   public static final int TYPE_FINISHED_SUCCESS = 0;
   public static final int TYPE_FINISHED_FAILED = 1;
   public static final int TYPE_TIMEOUT = 2;
   public static final int TYPE_INVALID_OPERATION = 3;
   public static final int TYPE_INTERNAL_ERROR = 4;
   public static final int TYPE_SERVER_DISCONNECT = 5;
   public static final int TYPE_UNKNOWN = 255;
   public String clientId;
   public int code;
   public String reason;
   public static final ByteBuffer ratelimitPacketTooMany = ByteBuffer.wrap(new byte[]{-4, 0});
   public static final ByteBuffer ratelimitPacketBlock = ByteBuffer.wrap(new byte[]{-4, 1});
   public static final ByteBuffer ratelimitPacketBlockLock = ByteBuffer.wrap(new byte[]{-4, 2});
   public static final ByteBuffer ratelimitPacketLocked = ByteBuffer.wrap(new byte[]{-4, 3});

   public RelayPacketFEDisconnectClient() {
   }

   public RelayPacketFEDisconnectClient(String clientId, int code, String reason) {
      this.clientId = clientId;
      this.code = code;
      this.reason = reason;
   }

   public void read(DataInputStream input) throws IOException {
      this.clientId = readASCII8(input);
      this.code = input.read();
      this.reason = readASCII16(input);
   }

   public void write(DataOutputStream output) throws IOException {
      writeASCII8(output, this.clientId);
      output.write(this.code);
      writeASCII16(output, this.reason);
   }

   public int packetLength() {
      return 4 + this.clientId.length() + (this.reason != null ? this.reason.length() : 0);
   }
}
