package net.lax1dude.eaglercraft.v1_8.sp.relay.server;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import net.lax1dude.eaglercraft.v1_8.sp.relay.pkt.IRelayLogger;

public class DebugLogger implements IRelayLogger {
   private static DebugLogger.Level debugLoggingLevel;
   private static final Map<String, DebugLogger> loggers;
   private final String name;
   private OutputStream infoOutputStream = null;
   private PrintStream infoPrintStream = null;
   private OutputStream warnOutputStream = null;
   private PrintStream warnPrintStream = null;
   private OutputStream errorOutputStream = null;
   private PrintStream errorPrintStream = null;
   private static final SimpleDateFormat fmt;

   public static void enableDebugLogging(DebugLogger.Level level) {
      if (level == null) {
         level = DebugLogger.Level.NONE;
      }

      debugLoggingLevel = level;
   }

   public static boolean debugLoggingEnabled() {
      return debugLoggingLevel != DebugLogger.Level.NONE;
   }

   public static DebugLogger getLogger(String name) {
      synchronized(loggers) {
         DebugLogger ret = (DebugLogger)loggers.get(name);
         if (ret == null) {
            ret = new DebugLogger(name);
            loggers.put(name, ret);
         }

         return ret;
      }
   }

   private DebugLogger(String name) {
      this.name = name;
   }

   public OutputStream getOutputStream(DebugLogger.Level lvl) {
      switch(lvl) {
      case INFO:
      default:
         if (this.infoOutputStream == null) {
            this.infoOutputStream = new DebugLogger.LogStream(DebugLogger.Level.INFO);
         }

         return this.infoOutputStream;
      case WARN:
         if (this.warnOutputStream == null) {
            this.warnOutputStream = new DebugLogger.LogStream(DebugLogger.Level.WARN);
         }

         return this.warnOutputStream;
      case ERROR:
         if (this.errorOutputStream == null) {
            this.errorOutputStream = new DebugLogger.LogStream(DebugLogger.Level.ERROR);
         }

         return this.errorOutputStream;
      }
   }

   public PrintStream getPrintStream(DebugLogger.Level lvl) {
      switch(lvl) {
      case INFO:
      default:
         if (this.infoPrintStream == null) {
            this.infoPrintStream = new PrintStream(this.getOutputStream(DebugLogger.Level.INFO));
         }

         return this.infoPrintStream;
      case WARN:
         if (this.warnPrintStream == null) {
            this.warnPrintStream = new PrintStream(this.getOutputStream(DebugLogger.Level.WARN));
         }

         return this.warnPrintStream;
      case ERROR:
         if (this.errorPrintStream == null) {
            this.errorPrintStream = new PrintStream(this.getOutputStream(DebugLogger.Level.ERROR));
         }

         return this.errorPrintStream;
      }
   }

   public static String formatParams(String msg, Object... params) {
      if (params.length <= 0) {
         return msg;
      } else {
         StringBuilder builtString = new StringBuilder();

         for(int i = 0; i < params.length; ++i) {
            int idx = msg.indexOf("{}");
            if (idx == -1) {
               break;
            }

            builtString.append(msg.substring(0, idx));
            if (params[i] instanceof InetSocketAddress) {
               params[i] = Util.sock2String((InetSocketAddress)params[i]);
            }

            builtString.append(params[i]);
            msg = msg.substring(idx + 2);
         }

         builtString.append(msg);
         return builtString.toString();
      }
   }

   public void log(DebugLogger.Level lvl, String msg, Object... params) {
      if (debugLoggingLevel.level >= lvl.level) {
         Date d = new Date();
         d.setTime(System.currentTimeMillis());
         String str = "[" + fmt.format(d) + "][" + Thread.currentThread().getName() + "/" + lvl.label + "][" + this.name + "]: " + (params.length == 0 ? msg : formatParams(msg, params));
         synchronized(this) {
            System.out.println(str);
         }
      }

   }

   public void log(DebugLogger.Level lvl, Throwable stackTrace) {
      synchronized(this) {
         stackTrace.printStackTrace(this.getPrintStream(lvl));
      }
   }

   public void debug(String msg) {
      if (debugLoggingLevel.level >= DebugLogger.Level.DEBUG.level) {
         this.log(DebugLogger.Level.DEBUG, msg);
      }

   }

   public void debug(String msg, Object... params) {
      if (debugLoggingLevel.level >= DebugLogger.Level.DEBUG.level) {
         this.log(DebugLogger.Level.DEBUG, msg, params);
      }

   }

   public void debug(Throwable t) {
      if (debugLoggingLevel.level >= DebugLogger.Level.DEBUG.level) {
         this.log(DebugLogger.Level.DEBUG, t);
      }

   }

   public void info(String msg) {
      if (debugLoggingLevel.level >= DebugLogger.Level.INFO.level) {
         this.log(DebugLogger.Level.INFO, msg);
      }

   }

   public void info(String msg, Object... params) {
      if (debugLoggingLevel.level >= DebugLogger.Level.INFO.level) {
         this.log(DebugLogger.Level.INFO, msg, params);
      }

   }

   public void info(Throwable t) {
      if (debugLoggingLevel.level >= DebugLogger.Level.INFO.level) {
         this.log(DebugLogger.Level.INFO, t);
      }

   }

   public void warn(String msg) {
      if (debugLoggingLevel.level >= DebugLogger.Level.WARN.level) {
         this.log(DebugLogger.Level.WARN, msg);
      }

   }

   public void warn(String msg, Object... params) {
      if (debugLoggingLevel.level >= DebugLogger.Level.WARN.level) {
         this.log(DebugLogger.Level.WARN, msg, params);
      }

   }

   public void warn(Throwable t) {
      if (debugLoggingLevel.level >= DebugLogger.Level.WARN.level) {
         this.log(DebugLogger.Level.WARN, t);
      }

   }

   public void error(String msg) {
      if (debugLoggingLevel.level >= DebugLogger.Level.ERROR.level) {
         this.log(DebugLogger.Level.ERROR, msg);
      }

   }

   public void error(String msg, Object... params) {
      if (debugLoggingLevel.level >= DebugLogger.Level.ERROR.level) {
         this.log(DebugLogger.Level.ERROR, msg, params);
      }

   }

   public void error(Throwable t) {
      if (debugLoggingLevel.level >= DebugLogger.Level.ERROR.level) {
         this.log(DebugLogger.Level.ERROR, t);
      }

   }

   static {
      debugLoggingLevel = DebugLogger.Level.INFO;
      loggers = new HashMap();
      fmt = new SimpleDateFormat("hh:mm:ss+SSS");
   }

   public static enum Level {
      NONE("NONE", 0, System.out),
      DEBUG("DEBUG", 4, System.out),
      INFO("INFO", 3, System.out),
      WARN("WARN", 2, System.err),
      ERROR("ERROR", 1, System.err);

      public final String label;
      public final int level;
      public final PrintStream output;

      private Level(String label, int level, PrintStream output) {
         this.label = label;
         this.level = level;
         this.output = output;
      }

      // $FF: synthetic method
      private static DebugLogger.Level[] $values() {
         return new DebugLogger.Level[]{NONE, DEBUG, INFO, WARN, ERROR};
      }
   }

   private class LogStream extends OutputStream {
      private final DebugLogger.Level logLevel;
      private final ByteArrayOutputStream lineBuffer;

      private LogStream(DebugLogger.Level logLevel) {
         this.lineBuffer = new ByteArrayOutputStream();
         this.logLevel = logLevel;
      }

      public void write(int b) throws IOException {
         if (b != 13) {
            if (b == 10) {
               byte[] line = this.lineBuffer.toByteArray();
               this.lineBuffer.reset();
               DebugLogger.this.log(this.logLevel, new String(line, StandardCharsets.UTF_8));
            } else {
               this.lineBuffer.write(b);
            }

         }
      }

      // $FF: synthetic method
      LogStream(DebugLogger.Level x1, Object x2) {
         this(x1);
      }
   }
}
