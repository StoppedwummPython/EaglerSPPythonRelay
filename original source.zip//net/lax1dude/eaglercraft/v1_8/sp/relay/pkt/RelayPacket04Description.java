package net.lax1dude.eaglercraft.v1_8.sp.relay.pkt;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class RelayPacket04Description extends RelayPacket {
   public String peerId;
   public byte[] description;

   public RelayPacket04Description() {
   }

   public RelayPacket04Description(String peerId, String desc) {
      this.peerId = peerId;
      this.description = toASCIIBin(desc);
   }

   public RelayPacket04Description(String peerId, byte[] desc) {
      this.peerId = peerId;
      this.description = desc;
   }

   public void read(DataInputStream input) throws IOException {
      this.peerId = readASCII8(input);
      this.description = readBytes16(input);
   }

   public void write(DataOutputStream output) throws IOException {
      writeASCII8(output, this.peerId);
      writeBytes16(output, this.description);
   }

   public String getDescriptionString() {
      return this.description == null ? null : toASCIIStr(this.description);
   }

   public int packetLength() {
      return 1 + this.peerId.length() + 2 + this.description.length;
   }
}
