package net.lax1dude.eaglercraft.v1_8.sp.relay.server;

import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;

public class ByteBufferInputStream extends InputStream {
   private final ByteBuffer buffer;

   public ByteBufferInputStream(ByteBuffer buf) {
      this.buffer = buf;
   }

   public int read(byte[] b, int off, int len) throws IOException {
      int max = this.buffer.remaining();
      if (len > max) {
         len = max;
      }

      this.buffer.get(b, off, len);
      return len;
   }

   public int read() throws IOException {
      return this.buffer.remaining() == 0 ? -1 : this.buffer.get() & 255;
   }

   public long skip(long n) throws IOException {
      int max = this.buffer.remaining();
      if (n > (long)max) {
         n = (long)max;
      }

      return (long)max;
   }

   public int available() throws IOException {
      return this.buffer.remaining();
   }

   public synchronized void mark(int readlimit) {
      this.buffer.mark();
   }

   public synchronized void reset() throws IOException {
      this.buffer.reset();
   }

   public boolean markSupported() {
      return true;
   }
}
