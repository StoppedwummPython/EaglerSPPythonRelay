package net.lax1dude.eaglercraft.v1_8.sp.relay.pkt;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

public class RelayPacket01ICEServers extends RelayPacket {
   public final Collection<RelayPacket01ICEServers.RelayServer> servers;

   public RelayPacket01ICEServers() {
      this.servers = new ArrayList();
   }

   public RelayPacket01ICEServers(Collection<RelayPacket01ICEServers.RelayServer> servers) {
      this.servers = servers;
   }

   public void write(DataOutputStream output) throws IOException {
      int l = this.servers.size();
      output.writeShort(l);
      Iterator itr = this.servers.iterator();

      while(itr.hasNext()) {
         RelayPacket01ICEServers.RelayServer srv = (RelayPacket01ICEServers.RelayServer)itr.next();
         if (srv.type == RelayPacket01ICEServers.RelayType.NO_PASSWD) {
            output.write(83);
         } else {
            if (srv.type != RelayPacket01ICEServers.RelayType.PASSWD) {
               throw new IOException("Unknown/Unsupported Relay Type: " + srv.type.name());
            }

            output.write(84);
         }

         writeASCII16(output, srv.address);
         writeASCII8(output, srv.username);
         writeASCII8(output, srv.password);
      }

   }

   public void read(DataInputStream input) throws IOException {
      this.servers.clear();
      int l = input.readUnsignedShort();

      for(int i = 0; i < l; ++i) {
         char type = (char)input.read();
         RelayPacket01ICEServers.RelayType typeEnum;
         if (type == 'S') {
            typeEnum = RelayPacket01ICEServers.RelayType.NO_PASSWD;
         } else {
            if (type != 'T') {
               throw new IOException("Unknown/Unsupported Relay Type: '" + type + "'");
            }

            typeEnum = RelayPacket01ICEServers.RelayType.PASSWD;
         }

         this.servers.add(new RelayPacket01ICEServers.RelayServer(readASCII16(input), typeEnum, readASCII8(input), readASCII8(input)));
      }

   }

   public static class RelayServer {
      public String address;
      public RelayPacket01ICEServers.RelayType type;
      public String username;
      public String password;

      public RelayServer(String address, RelayPacket01ICEServers.RelayType type, String username, String password) {
         this.address = address;
         this.type = type;
         this.username = username;
         this.password = password;
      }

      public String getICEString() {
         return this.username == null ? this.address : this.address + ";" + this.username + ";" + this.password;
      }
   }

   public static enum RelayType {
      NO_PASSWD,
      PASSWD;

      // $FF: synthetic method
      private static RelayPacket01ICEServers.RelayType[] $values() {
         return new RelayPacket01ICEServers.RelayType[]{NO_PASSWD, PASSWD};
      }
   }
}
