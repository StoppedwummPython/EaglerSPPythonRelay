package net.lax1dude.eaglercraft.v1_8.sp.relay.server;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class RateLimiter {
   private final int period;
   private final int limit;
   private final int lockoutLimit;
   private final int lockoutDuration;
   private final Map<String, RateLimiter.RateLimitEntry> limiters = new HashMap();

   public RateLimiter(int period, int limit, int lockoutLimit, int lockoutDuration) {
      this.period = period;
      this.limit = limit;
      this.lockoutLimit = lockoutLimit;
      this.lockoutDuration = lockoutDuration;
   }

   public synchronized RateLimiter.RateLimit limit(String addr) {
      RateLimiter.RateLimitEntry etr = (RateLimiter.RateLimitEntry)this.limiters.get(addr);
      if (etr == null) {
         etr = new RateLimiter.RateLimitEntry();
         this.limiters.put(addr, etr);
      } else {
         etr.update();
      }

      if (etr.locked) {
         return RateLimiter.RateLimit.LOCKOUT;
      } else {
         ++etr.count;
         if (etr.count >= this.lockoutLimit) {
            etr.count = 0;
            etr.locked = true;
            etr.lockedTimer = Util.millis();
            return RateLimiter.RateLimit.LIMIT_NOW_LOCKOUT;
         } else {
            return etr.count > this.limit ? RateLimiter.RateLimit.LIMIT : RateLimiter.RateLimit.NONE;
         }
      }
   }

   public synchronized void update() {
      Iterator itr = this.limiters.values().iterator();

      while(itr.hasNext()) {
         if (((RateLimiter.RateLimitEntry)itr.next()).count == 0) {
            itr.remove();
         }
      }

   }

   public synchronized void reset() {
      this.limiters.clear();
   }

   private class RateLimitEntry {
      protected long timer = Util.millis();
      protected int count = 0;
      protected long lockedTimer = 0L;
      protected boolean locked = false;

      protected RateLimitEntry() {
      }

      protected void update() {
         long millis = Util.millis();
         if (this.locked) {
            if (millis - this.lockedTimer > (long)RateLimiter.this.lockoutDuration) {
               this.timer = millis;
               this.count = 0;
               this.lockedTimer = 0L;
               this.locked = false;
            }
         } else {
            long p = (long)(RateLimiter.this.period / RateLimiter.this.limit);
            int breaker = 0;

            do {
               if (millis - this.timer <= p) {
                  return;
               }

               this.timer += p;
               --this.count;
               if (this.count < 0) {
                  break;
               }

               ++breaker;
            } while(breaker <= 100);

            this.timer = millis;
            this.count = 0;
         }

      }
   }

   public static enum RateLimit {
      NONE,
      LIMIT,
      LIMIT_NOW_LOCKOUT,
      LOCKOUT;

      // $FF: synthetic method
      private static RateLimiter.RateLimit[] $values() {
         return new RateLimiter.RateLimit[]{NONE, LIMIT, LIMIT_NOW_LOCKOUT, LOCKOUT};
      }
   }
}
